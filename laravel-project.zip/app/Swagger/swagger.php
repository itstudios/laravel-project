<?php

/**
 * @OA\Info(
 *     title="Telegram Bot API",
 *     description="API for interacting with the Telegram bot",
 *     version="1.0.0"
 * )
 */
